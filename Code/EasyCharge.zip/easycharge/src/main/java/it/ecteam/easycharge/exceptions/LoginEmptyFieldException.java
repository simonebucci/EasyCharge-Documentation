package it.ecteam.easycharge.exceptions;

public class LoginEmptyFieldException extends EmptyFieldException {

    public LoginEmptyFieldException(String message) {
        super(message);
    }

}