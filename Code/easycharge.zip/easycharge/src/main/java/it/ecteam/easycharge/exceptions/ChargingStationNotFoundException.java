package it.ecteam.easycharge.exceptions;

public class ChargingStationNotFoundException extends Exception {
    public ChargingStationNotFoundException(String message) {
        super(message);
    }
}


